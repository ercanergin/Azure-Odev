<?php
$host= "localhost";
$kullanici="root";
$dbSifre="";
$veritabani= "obs_database";
$baglan= mysqli_connect ($host,$kullanici,$dbSifre,$veritabani);

?>